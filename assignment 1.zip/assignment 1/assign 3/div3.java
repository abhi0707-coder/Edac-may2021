public class div3
{

public static void main(String[] args) {
	int a = 50;
	int b = 3;
	int c = (a/b);
	
	System.out.println(c);

}
}