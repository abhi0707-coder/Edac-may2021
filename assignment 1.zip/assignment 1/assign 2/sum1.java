public class sum1 {

   public static void main(String[] args) {
        
      int num1 = 74, num2 = 36, sum;
      sum = num1 + num2;

      System.out.println("Sum of these numbers: "+sum);
   }
}