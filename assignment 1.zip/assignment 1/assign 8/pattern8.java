public class pattern8
{
public static void main(String[] args)
{
System.out.println("  j   a  v     v  a ");
System.out.println("  j  a  a  v  v  a  a");
System.out.println("j j  aaaa   v v  aaaa");
System.out.println(" jj a     a  v  a     a");
}

}